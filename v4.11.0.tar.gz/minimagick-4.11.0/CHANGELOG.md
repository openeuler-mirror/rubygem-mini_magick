We keep the changelog in [GitHub releases](https://github.com/minimagick/minimagick/releases).
