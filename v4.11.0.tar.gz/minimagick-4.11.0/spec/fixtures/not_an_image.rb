expect(__FILE__).not_to be_an_image
